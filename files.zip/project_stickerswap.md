---
name: project-stickerscout
description: StickerScout 2026 — app at C:\Coding\StickerScout2026
metadata: 
  node_type: memory
  type: project
  originSessionId: e3ea0cf0-4a2e-44bb-93e0-b89c332c78c0
---

**App Name:** StickerScout 2026
**Location:** `C:\Coding\StickerScout2026`
**Package:** `at.ncn.stickerscout2026`
**Stack:** Expo SDK 56, React 19, AsyncStorage (no Redux), RevenueCat
**Sprachen:** DE + EN + ES + PT + FR (5 Sprachen, globaler Markt)
**Build:** Release AAB v1.0.2 fertig (PaywallRedesign, Ringtones, Push, 5 Sprachen, RevenueCat, Multidex-Fix)
**Prompt:** v3.1 (3. Juni 2026) — `C:\Coding\StickerScout2026_Zusatzdaten\StickerScout2026_ClaudeCode_Prompt_v3.1.md`

---

## Store IDs
- iOS: Apple ID `6775562727`, Bundle `at.ncn.stickerscout2026`, Team `559ZU7L5U4`, Login `roman.neuner@ncn.at`
- Android: Package `at.ncn.stickerscout2026`
- EAS Project: `f5b15be1-3563-403e-b727-295af9f553c2` (user: rommi)
- Google Service Account: `C:\Coding\StickerScout2026\google-service-account.json`

---

## Collections (v3.1)
- **Sticker DB v7.1:** 980 base + CC1-CC12 + EXTRA1-EXTRA20 = **1.012 total** (foto-verifiziert)
- **Adrenalyn DB v2.2:** 630 Base + 48 HERO (U01-U48) + 2 Limited Edition = **680 total**
- Sticker IDs: `[TEAMCODE][1-20]` z.B. AUT4, CC1-CC12, EXTRA1-20, FWC1-19, 00
- Adrenalyn: GOLDEN_BALLER(#1-9) / FF / TEAM_CREST / IC / BASE / HERO / LIMITED_EDITION / CONTENDER

---

## Gruppen
```
A: MEX RSA KOR CZE | G: BEL EGY IRN NZL
B: CAN BIH QAT SUI | H: ESP CPV KSA URU
C: BRA MAR HAI SCO | I: FRA SEN IRQ NOR
D: USA PAR AUS TUR | J: ARG ALG AUT JOR ← Österreich!
E: GER CUW CIV ECU | K: POR COD UZB COL
F: NED JPN SWE TUN | L: ENG CRO GHA PAN
```
AUT-Spiele: 17.06. vs JOR | 22.06. vs ARG | 28.06. vs ALG

---

## Design System: Stadion-Nacht v2.0
- Background: `#0D1F2D` | Gold: `#F5C033` | Blue: `#4FC3F7` | Green: `#42D783` | Red: `#FF6B6B`
- Theme: `src/theme/index.js` — alle COLORS, GRADIENTS, FONTS, SPACING, RADIUS, SHADOWS

---

## Monetarisierung (v3.1 — kein Abo)
- `at.ncn.stickerscout2026.wmpass` — WM Pass Non-consumable €3,99 (EB €2,99 / AT €1,99 bis 15.06.)
- `at.ncn.stickerscout2026.scan50` — +50 Scans Consumable €0,99
- `at.ncn.stickerscout2026.trade7d` — +10 Trade-Slots 7 Tage €0,99
- `at.ncn.stickerscout2026.report` — PDF Report Non-consumable €0,99
- `at.ncn.stickerscout2026.ringtone.song1` — One World, One Game – Klingelton €0,99
- `at.ncn.stickerscout2026.ringtone.song2` — Wir stehen zusammen – Klingelton €0,99
- `at.ncn.stickerscout2026.ringtone.song3` — Unaufhoitboa – Klingelton €0,99
- `at.ncn.stickerscout2026.fulltrack.song1` — One World, One Game – Full Track €1,99 ← NEU
- `at.ncn.stickerscout2026.fulltrack.song2` — Wir stehen zusammen – Full Track €1,99 ← NEU
- `at.ncn.stickerscout2026.fulltrack.song3` — Unaufhoitboa – Full Track €1,99 ← NEU
- Free-Limit: **10 Scans/Tag**, 5 Trade-Angebote

---

## Scan-Flow v3 (5. Juni 2026) — TYPGESTEUERT
```
Schritt 1: Typ-Auswahl → [Sticker] [Adrenalyn-Karte]
  (KEIN Vorder-/Rückseite-Toggle mehr!)

Schritt 2 — automatisch die richtige Seite:
├── STICKER → nur RÜCKSEITE (Sticker-ID z.B. "ALG8")
├── ADRENALYN NORMAL → nur VORDERSEITE (Nummer oben links z.B. "191")
└── GOLDEN BALLER (Gold erkannt) → Vorderseite + Rückseite (Activation Code)

Schritt 3: Fallback immer sichtbar "Nummer manuell eingeben"
```
- WICHTIG: pro Typ nur EINE relevante Seite (außer Golden Baller)
- Sticker-ID steht HINTEN, Adrenalyn-Nummer steht VORNE
- KI-Bilderkennung: NICHT in v1.0 → kommt v2.0
- ALTE Version (v1.0.2) hatte falschen Vorder/Rückseite-Toggle → muss umgebaut werden

---

## Architektur
```
src/
├── screens/
│   ├── ScanScreen.js       — Kamera + OCR (ML Kit) + manuell
│   ├── AlbumScreen.js      — Sticker Tab + Adrenalyn Tab
│   ├── TradeScreen.js      — Tauschbörse + Standort
│   ├── ScheduleScreen.js   — Spielplan 104 Spiele
│   ├── AssistantScreen.js  — Claude AI Chat (Haiku)
│   ├── ProfileScreen.js    — Stats + Promo Codes + Settings
│   ├── PaywallScreen.js    — WM Pass + Micro-IAPs + AT-Preis
│   ├── RingtonesScreen.js  — WM Klingeltöne ← NEU
│   └── OnboardingScreen.js
├── data/
│   ├── stickerCatalog.js   — lookupSticker(), CC/EXTRA/FWC/team
│   ├── adrenalynCatalog.js — lookupAdrenalyn(), SPECIAL_CARDS_FLAT
│   ├── stickerTypes.js     — TEAM_FLAGS (48 teams)
│   └── schedule.js
├── assets/
│   ├── icons/              — Custom PNG Icons (gold/grey/white/dark)
│   └── ringtones/          — 3 Songs (MP3 + M4R) ← NEU
│       ├── song1_preview.mp3 / song1_full.mp3 / song1_full.m4r
│       ├── song2_preview.mp3 / song2_full.mp3 / song2_full.m4r
│       └── song3_preview.mp3 / song3_full.mp3 / song3_full.m4r
├── services/
│   ├── storage.js          — AsyncStorage, FREE_SCAN_LIMIT=10
│   └── subscription.js     — RevenueCat WM Pass + Micro-IAPs + Ringtones
├── components/
│   ├── AppIcon.js          — Custom PNG Icons
│   ├── GoldButton.js
│   └── StickerBadge.js
├── hooks/useAnimations.js
├── theme/index.js
└── i18n.js                 — DE (primär) + EN
```

---

## Navigation
```
Bottom Navigation (6 Tabs):
[Scan] [Album] [Tausch] [Spiele] [🔔 Töne] [Profil]
```
Ringtones-Tab Icon: `ti-bell-ringing` (Tabler, gold wenn aktiv)

---

## Features — Status (Stand: 3. Juni 2026)
| Feature | Status | Notiz |
|---|---|---|
| Scanner + OCR (ML Kit) | ✅ | 3-Pfad-Flow v2 |
| Album: Sticker (1.012) | ✅ | |
| Album: Adrenalyn XL (680) | ✅ | |
| Tauschbörse + Standort | ✅ | |
| Spielplan 104 Spiele | ✅ | |
| Claude In-App Assistent | ✅ | |
| Paywall (AT-Preis, Early Bird) | ✅ | |
| Design Stadion-Nacht | ✅ | |
| Onboarding | ✅ | |
| i18n DE + EN | ✅ | |
| Release AAB v1.0.2 | ✅ | dist/stickerscout-v1.0.2.aab (140 MB) |
| PaywallScreen Redesign | ✅ | kein Abo-Text, Dream Team, Vector-Icons |
| Push Notifications | ✅ | expo-notifications |
| App Store Screenshots | ✅ | 5x 1284×2778px hochgeladen |
| **WM Ringtones Tab** | ✅ | RingtonesScreen nach HTML-Vorlage, echte Songs |
| RevenueCat Offerings | ✅ | Offerings-System v1.0.2 |
| RevenueCat echte API Keys | ⚠️ | RC Keys noch in .env prüfen |
| iOS Build | ⚠️ | Morgen nach Claude Code-Build |
| Google Play IAP-Preise | ⚠️ | Nach erstem APK-Upload |

---

## WM Ringtones (NEU — v1.0 Launch)
| ID | Künstler | Titel | Markt |
|---|---|---|---|
| song1 | United Voices | One World, One Game | 🌍 INT |
| song2 | Leo Falk | Wir stehen zusammen | 🇩🇪 DE |
| song3 | Da Austro-Bua | Unaufhoitboa | 🇦🇹 AT |

- Format: MP3 + M4R (iOS) — lokal bei Roman → `assets/ringtones/`
- Cover Art: `assets/ringtones/covers/song[1-3]_cover.png`
- Klingelton IAPs: song1/2/3 (€0,99, Non-consumable)
- Full Track IAPs: fulltrack.song1/2/3 (€1,99, Non-consumable) ← NEU
- Upsell: nach Klingelton-Kauf → "Ganzen Song für €1,00 mehr"
- "Als Klingelton setzen": iOS via Share Sheet (.m4r), Android via MediaStore

## ⚠️ iOS Klingelton-Einschränkung (WICHTIG für iOS-Build)
- Apple erlaubt KEINE programmatische Klingelton-Installation!
- iOS: App exportiert .m4r → User muss MANUELL via GarageBand/Dateien-App importieren → Anleitungs-Screen nötig
- Android: funktioniert direkt via RingtoneManager + WRITE_SETTINGS
- SPEICHERORT (final): Klingelton UND Full Track → Music/StickerScout/
  - Android: MediaStore RELATIVE_PATH = "Music/StickerScout"
  - In anderen Musik-Apps sicht-/abspielbar
- iOS-Build noch NICHT erstellt (Stand v1.0.2 = nur Android AAB)

---

## Custom Icons
Quelle: `C:\Coding\StickerScout2026\screen\icons_extracted\StickerScout2026_Web_Icon_Assets\`
Icons in `assets/icons/` — Varianten: gold/grey/white/dark (PNG 1024px)
Verfügbar: scan, album-book, calendar, profile-user, camera, flash-zap, gallery-image, shutter-circle, arrow-left, question-mark-circle, crown-pro, barcode-number, home

---

## Build
```powershell
# Android Debug (auf Gerät)
$env:GRADLE_USER_HOME = "C:\GradleHome"
$env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
$env:PATH = "$env:JAVA_HOME\bin;" + $env:PATH
cd "C:\Coding\StickerScout2026"
npx expo run:android

# Release AAB für Play Store
cd android; .\gradlew.bat bundleRelease
# → AAB nach dist/ kopieren als stickerscout-v{version}.aab
```

## Release Keystore
- Datei: `android/app/stickerscout-release.keystore`
- Backup: `C:\Coding\StickerScout2026_Zusatzdaten\stickerscout-release.keystore`
- Password: `stickerscout2026` | Alias: `stickerscout`

## .env Keys
```
EXPO_PUBLIC_RC_IOS_KEY=appl_...              ← noch einzutragen ⚠️
EXPO_PUBLIC_RC_ANDROID_KEY=goog_...          ← noch einzutragen ⚠️
EXPO_PUBLIC_CLAUDE_API_KEY=sk-ant-api03-...  ← eingetragen ✅
```

## Metro starten
```powershell
cd "C:\Coding\StickerScout2026"
adb reverse tcp:8081 tcp:8081
npx expo start --port 8081 --clear
```

---

## Offene Punkte (Stand 3. Juni 2026)
1. ⚠️ RevenueCat API Keys (iOS + Android) in .env eintragen
2. ⚠️ Ringtone-Dateien (3x MP3+M4R) in `assets/ringtones/` ablegen
3. ⚠️ 3 neue IAPs (ringtone.song1/2/3) in App Store Connect anlegen
4. ⚠️ iOS Build erstellen + App Store Submit (spätestens 9. Juni)
5. ⚠️ Google Play: erstes APK hochladen → IAP-Preise danach anlegen
6. ⚠️ Panini Affiliate klären (Code 00540AD)
7. ⚠️ App Store Texte reviewen (morgen)
