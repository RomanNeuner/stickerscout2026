# StickerScout 2026 — Claude Code Prompt
**NCN-NetConsulting GmbH | Version 3.1 | 3. Juni 2026**

> **Änderungen v3.1 gegenüber v3.0:**
> - Scan-Flow komplett überarbeitet (adaptiver 3-Pfad-Flow)
> - KI-Erkennung auf v2.0 verschoben — Launch ohne Bilderkennung
> - Monetarisierung: WM Pass einmalig + Micro-IAPs (nicht mehr Abo)
> - Scan-Limit: 10/Tag (nicht 20)
> - Design System: Stadion-Nacht Blau (#0D1F2D)
> - Adrenalyn DB: v2.2 (680 Karten inkl. Update Set + HERO-Typ)
> - Sticker DB: v7.1 (alle 7 verbleibenden Teams foto-verifiziert)
> - Österreich Sonderpreis: €1,99 Early Bird
> - IAP Produkt-IDs finalisiert

---

# 🇩🇪 DEUTSCH

## Projektkontext

Entwickle **StickerScout 2026** — eine React Native App für iOS und Android zur FIFA Fußball-Weltmeisterschaft 2026. KI-gestützter Begleiter für Sticker- und Trading-Card-Sammler, der BEIDE offiziellen Panini-Kollektionen unterstützt.

**Basis:** Gleiche Architektur wie **AI Coin Collection Platform (CoinScanner)** — React Native, Firebase, Expo Camera + Google ML Kit.

**Developer:** NCN-NetConsulting GmbH (Österreich)
**Bundle ID iOS:** `at.ncn.stickerscout2026`
**Package Android:** `at.ncn.stickerscout2026`
**Launch:** 11. Juni 2026
**Sprachen:** Deutsch + Englisch + Spanisch + Portugiesisch + Französisch (5 Sprachen, globaler Markt)

---

## Design System — Stadion-Nacht

**Alle Screens verwenden dieses Farbsystem:**

```javascript
// colors.js — verbindlich für alle Screens
export const colors = {
  background: {
    primary:  '#0D1F2D',               // Haupthintergrund
    card:     'rgba(255,255,255,0.05)', // Karten
    overlay:  'rgba(13,31,45,0.95)',    // Modals
    input:    'rgba(255,255,255,0.06)',
  },
  gold:  '#F5C033',   // WM-Trophy-Gold — CTAs, Icons, Highlights
  blue:  '#4FC3F7',   // Flutlicht-Blau — Badges, Info-Chips
  green: '#42D783',   // Erfolg — Checkmarks, neue Sticker
  red:   '#FF6B6B',   // Fehler / AT-Badge
  text: {
    primary:   '#FFFFFF',
    secondary: 'rgba(255,255,255,0.65)',
    muted:     'rgba(255,255,255,0.35)',
    gold:      '#F5C033',
    blue:      '#4FC3F7',
  },
  border: {
    default: 'rgba(255,255,255,0.10)',
    gold:    'rgba(245,192,51,0.40)',
    blue:    'rgba(79,195,247,0.35)',
  },
  cta: { background: '#F5C033', text: '#0D1F2D' },
};
```

**StatusBar:** immer `style="light"` (helle Icons auf dunklem Hintergrund)

---

## Kollektionen & Datenbanken

### A) Panini Sticker-Kollektion
**Datei:** `sticker_db_wc2026.json` **v7.1** (foto-verifiziert, final)

| Sektion | Anzahl | ID-Format |
|---|---|---|
| Base Sticker | 980 | `[TEAMCODE][1-20]` z.B. `AUT4` |
| Coca-Cola Sticker | 12 | `CC1`–`CC12` |
| Extra Sticker | 20 | `EXTRA1`–`EXTRA20` |
| **Total für 100%** | **1.012** | |

**Sticker-Rückseite:** Jeder Sticker hat den Spielercode auf der Rückseite (z.B. `ALG8`). Das ist die primäre Eingabe bei v1.0 (ohne KI-Bilderkennung).

**48 Teams in 12 Gruppen:**
```
A: MEX RSA KOR CZE   |  G: BEL EGY IRN NZL
B: CAN BIH QAT SUI   |  H: ESP CPV KSA URU
C: BRA MAR HAI SCO   |  I: FRA SEN IRQ NOR
D: USA PAR AUS TUR   |  J: ARG ALG AUT JOR
E: GER CUW CIV ECU   |  K: POR COD UZB COL
F: NED JPN SWE TUN   |  L: ENG CRO GHA PAN
```

### B) Panini Adrenalyn XL Trading Cards
**Datei:** `adrenalyn_db_wc2026.json` **v2.2**

| Set | Karten | Beschreibung |
|---|---|---|
| Basis-Set | 630 | Karten #1–#630 |
| Update Set HERO | 48 | U01–U48, HERO-Typ |
| Update Set Limited | 2 | LE1 Marc Cucurella (ESP), LE2 Giuliano Simeone (ARG) |
| **Gesamt** | **680** | |

**Karten-Typen:**
- `GOLDEN_BALLER` — #1–#9 (Messi, Vinícius, Salah, Kane, Mbappé, Son, Haaland, Ronaldo, Yamal) — Gold-Foil, 100/100/100 = 300 Pkt.
- `FF` — Fan Favourite (erste Karte je Team)
- `TEAM_CREST` — Wappen-Karte (zweite Karte je Team)
- `IC` — Icon (dritte Karte je Team)
- `BASE` — reguläre Spielerkarte
- `HERO` — Update Set Upgrade-Karte (teilt Nummer mit BASE-Karte)
- `LIMITED_EDITION` — Cucurella + Simeone (aus Update Set Box)
- `CONTENDER` — Playoff-Teams (DEN/ITA/JAM/POL/SWE/TUR, je 5 Karten)

**WICHTIG — Kartennummer:**
Die Kartennummer steht **oben links auf der Vorderseite** jeder Karte (z.B. `#191` für Germany Team Crest). HERO-Karten teilen dieselbe Nummer wie die entsprechende BASE-Karte.

**HERO-Karten Erkennung:**
- Goldenes/buntes Foil-Design
- "HERO" Schriftzug auf der Karte
- Höhere Ratings als BASE-Version
- Aus dem Update Set (€15 Box, 48 HERO + 2 LE)

---

## Scan-Flow v2 — Adaptiver 3-Pfad-Flow

> **⚠️ KI-Bilderkennung ist NICHT in v1.0 enthalten.**
> v1.0 nutzt OCR (Google ML Kit Text Recognition) und manuelle Eingabe.
> Visuelle Spieler-Erkennung kommt in v2.0 (August 2026).

### Scan-Ablauf

```
┌─────────────────────────────────────────┐
│         VORDERSEITE SCANNEN             │
│   (Kamera erkennt Typ via Layout-OCR)   │
└────────────┬────────────────────────────┘
             │
    ┌────────┴────────────────┐
    │                         │
    ▼                         ▼
STICKER erkannt          ADRENALYN erkannt
(kleines Format,         (Kartennummer #XXX
 kein Foil-Rand)          oben links sichtbar)
    │                         │
    ▼                         ├── NORMAL CARD (#10–#630)
RÜCKSEITE scannen        │    │   → Nummer von Vorderseite
(liest Code z.B. ALG8)   │    │   Fallback: Nummer tippen
    │                    │    │
    ▼                    │    └── GOLDEN BALLER (#1–#9)
Sticker in DB suchen     │        Gold-Design + "GOLDEN BALLER"
→ Bestätigung anzeigen   │        → Vorderseite: Spieler + #
                         │        → RÜCKSEITE scannen:
FALLBACK:                │          liest ACTIVATION CODE
Nummer manuell tippen    │          (z.B. LCH-ZK-VIX)
                         │
                    FALLBACK:
                    Nummer tippen
```

### Erkennungsmerkmale

| Typ | Erkennungsmerkmal | Primäres Feld |
|---|---|---|
| Sticker | Kleines Format (50×65mm), kein Foil-Rand | Rückseite: `ALG8` |
| Adrenalyn normal | Kartenrand, Nummer #XXX oben links | Vorderseite: `#191` |
| Golden Baller | Gold-Foil, Nummer #1–#9, "GOLDEN BALLER" vertikal | Vorderseite + Rückseite |
| HERO-Karte | Foil-Design, "HERO" sichtbar, Nummer #XXX | Vorderseite: `#373` |

### Scan-Screen UI

```
┌──────────────────────────────┐
│       SCANNEN                │
│                              │
│  ┌──────────────────────┐    │
│  │  [Kamera-Viewfinder] │    │
│  │    ┌──────────┐      │    │
│  │    │ SCAN-    │      │    │
│  │    │ RAHMEN   │      │    │
│  │    └──────────┘      │    │
│  └──────────────────────┘    │
│                              │
│  [Vorderseite] [Rückseite]   │  ← Tab nur wenn relevant
│                              │
│  ──── oder ────              │
│  [Nummer manuell eingeben]   │  ← immer sichtbar (Fallback)
└──────────────────────────────┘
```

**Tab "Rückseite"** wird nur angezeigt:
- Immer bei Stickern (Pflicht für Code-Erkennung)
- Nur bei Golden Baller Karten (für Activation Code)
- NICHT bei normalen Adrenalyn-Karten

### OCR-Implementation

```javascript
import { GoogleMLKit } from 'expo-ml-kit';

// Sticker Rückseite → Code wie "ALG8"
async function scanStickerBack(imageUri) {
  const result = await GoogleMLKit.textRecognition(imageUri);
  // Sticker-Code: 2-3 Buchstaben + 1-2 Zahlen
  const match = result.text.match(/\b([A-Z]{2,4})(\d{1,2})\b/);
  if (match) {
    const code = match[1] + match[2]; // z.B. "ALG8"
    return lookupSticker(code);
  }
  return null; // → Fallback: manuelle Eingabe
}

// Adrenalyn Vorderseite → Kartennummer wie "#191"
async function scanCardFront(imageUri) {
  const result = await GoogleMLKit.textRecognition(imageUri);
  // Kartennummer: # + 1-3 Ziffern oben links
  const match = result.text.match(/#?(\d{1,3})\b/);
  if (match) {
    const num = parseInt(match[1]);
    return lookupCard(num);
  }
  return null;
}

// Golden Baller Rückseite → Activation Code
async function scanGoldenBallerBack(imageUri) {
  const result = await GoogleMLKit.textRecognition(imageUri);
  // Activation Code: XXX-XX-XXX Format
  const match = result.text.match(/([A-Z]{2,4}-[A-Z0-9]{2,4}-[A-Z0-9]{2,4})/);
  return match ? match[1] : null; // z.B. "LCH-ZK-VIX"
}
```

### Sticker Lookup

```javascript
import stickerDb from './assets/sticker_db_wc2026.json';
import adrenalynDb from './assets/adrenalyn_db_wc2026.json';

function lookupSticker(id) {
  if (id.startsWith('CC'))    return stickerDb.coca_cola_stickers.find(s => s.id === id);
  if (id.startsWith('EXTRA')) return stickerDb.extra_stickers.find(s => s.id === id);
  if (id.startsWith('FWC') || id === '00') return stickerDb.intro_stickers.find(s => s.id === id);
  const teamCode = id.replace(/\d+$/, '');
  const team = stickerDb.teams.find(t => t.code === teamCode);
  const sticker = team?.stickers.find(s => s.id === id);
  return sticker ? { ...sticker, team: team.name, group: team.group } : null;
}

function lookupCard(number) {
  // Zuerst Basis-Set (1-630)
  const baseCard = adrenalynDb.team_cards.find(c => c.number === number)
    || adrenalynDb.golden_ballers.find(c => c.number === number)
    || Object.values(adrenalynDb.special_cards).flat().find(c => c.number === number);
  if (baseCard) return { ...baseCard, setType: 'BASE' };

  // Dann Update Set HERO (gleiche Nummern, HERO-Typ)
  const heroCard = adrenalynDb.update_set?.upgrade_cards
    .find(c => c.id === `U${String(number).padStart(2,'0')}`);
  if (heroCard) return { ...heroCard, setType: 'HERO' };

  return null;
}
```

---

## Monetarisierung — WM Pass Modell

> **Kein Abo mehr.** Einmaliger WM Pass + optionale Micro-IAPs.

### IAP Produkte (Apple + Google Play)

| Produkt | Typ | Preis | Produkt-ID |
|---|---|---|---|
| WM Pass 2026 | Non-consumable | €3,99 | `at.ncn.stickerscout2026.wmpass` |
| +50 Scan-Boost | Consumable | €0,99 | `at.ncn.stickerscout2026.scan50` |
| +10 Trade-Slots (7 Tage) | Consumable | €0,99 | `at.ncn.stickerscout2026.trade7d` |
| Completion Report PDF | Non-consumable | €0,99 | `at.ncn.stickerscout2026.report` |

### Early Bird Preise

| Region | Early Bird (bis 15.06.) | Regular (ab 16.06.) |
|---|---|---|
| Weltweit | €2,99 | €3,99 |
| Österreich (AT) | **€1,99** | €3,99 |

**Österreich-Erkennung:**
```javascript
import * as Localization from 'expo-localization';
const isAustria = () => Localization.region === 'AT';
const wmPassPrice = isAustria() ? '€1,99' : '€2,99'; // Early Bird
```

### Feature-Tabelle

| Feature | Free | WM Pass |
|---|---|---|
| Scanner | **10/Tag** | Unbegrenzt |
| Tauschbörse | 5 Angebote | Unbegrenzt |
| Completion Calculator | Basic | Vollständig |
| Completion Report PDF | ❌ | ✅ (oder €0,99) |
| Dream Team Builder | 1 Team | Unbegrenzt |
| Werbung (AdMob) | ✅ | ❌ |
| Panini Affiliate Link | ✅ | ✅ |

**Affiliate:** Panini Code `00540AD`, 8% Provision

### Paywall Screen

Paywall wird getriggert wenn:
- User 10 Scans/Tag erreicht hat
- User auf Premium-Feature tippt (z.B. mehr Trade-Slots)

**Design:** Stadion-Nacht Blau (#0D1F2D), Gold CTA-Button

```
┌──────────────────────────────────┐
│  [WM Trophy Icon]                │
│  Mehr sammeln.                   │
│  Schneller komplett.             │
│                                  │
│  [Early Bird — noch X Tage]      │  ← Countdown bis 15.06.
│                                  │
│  [BESTES PAKET]      [25% sparen]│
│  €2,99 ~~€3,99~~ einmalig        │
│                                  │
│  ✓ Unbegrenzte Sticker-Scans     │
│  ✓ Alle Tauschplätze             │
│  ✓ KI-Duplikat-Erkennung         │
│  ✓ Sammelalbum-Auswertung PDF    │
│                                  │
│  [WM Pass für €2,99 holen]       │  ← Gold CTA
│                                  │
│  ──── oder einzeln kaufen ────   │
│  +50 Scan-Boost          €0,99   │
│  +10 Tauschplätze (7 Tage) €0,99 │
│  Sammelalbum-Auswertung   €0,99  │
│                                  │
│  Kostenlos weitermachen          │
│  Datenschutz · AGB · Wiederherstellen │
└──────────────────────────────────┘
```

---

## Features — Launch v1.0

### 1. SCANNER (ohne KI-Bilderkennung)

Siehe "Scan-Flow v2" oben. Basis-Technologie:
- **OCR:** Google ML Kit Text Recognition v2
- **Barcode:** ML Kit Barcode Scanning (für Promo-QR-Codes)
- **KEINE** visuelle Spieler-Erkennung bei Launch

### 2. DIGITALES ALBUM

**Tab A — Sticker (1.012 gesamt)**
- Grid-Ansicht nach Gruppen A–L
- Sektionen: Teams / Coca-Cola Special (CC1–CC12) / Extra Sticker (EXTRA1–EXTRA20)
- Filter: vorhanden / fehlend / doppelt / FOIL / CC / Extra
- Fortschrittsbalken: Album (980) / CC (12) / Extra (20) / Gesamt (1.012)

**Tab B — Adrenalyn XL (680 gesamt)**
- Grid nach Kategorie
- Typen: Golden Baller ⭐ / HERO 🦸 / IC / FF / BASE / Special / Limited
- HERO-Karten optisch von BASE unterscheidbar (goldener Rahmen)
- Online-Code-Status: eingelöst / verfügbar (nur Golden Baller)

### 3. COMPLETION CALCULATOR

```javascript
function calcCompletion(owned, total = 980) {
  const missing = total - owned;
  const expectedPacks = Math.round(missing * (total / (missing + 1)) / 7);
  return {
    owned, missing, total,
    expectedPacksNeeded: expectedPacks,
    estimatedCostEUR: (expectedPacks * 0.60).toFixed(2),
    completionPct: ((owned / total) * 100).toFixed(1)
  };
}
```

Premium: PDF-Export (`at.ncn.stickerscout2026.report`)

### 4. TAUSCHBÖRSE

- Free: 5 aktive Angebote | WM Pass: Unbegrenzt
- Matching: gegenseitiger Bedarf
- Geolokalisierung: Tauschpartner in der Nähe
- In-App-Chat
- Panini Nachbestellservice Deep-Link

### 5. SPIELPLAN & BRACKET

- Alle 104 WM-Spiele (11. Juni – 19. Juli 2026)
- Gruppe J (Österreich: ARG/ALG/AUT/JOR) hervorgehoben
- Bracket Predictor

### 6. DREAM TEAM BUILDER

- 11er-Team aus gescannten Adrenalyn-Karten
- Formationen: 4-3-3, 4-4-2, 3-5-2 etc.
- Teambewertung nach Karten-Ratings
- Free: 1 Team | WM Pass: Unbegrenzt

### 7. IN-APP ASSISTENT (Claude API)

```javascript
async function askAssistant(userMessage, userCollection) {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: `Du bist StickerScout, der persönliche Sammel-Assistent.
        Sammlung: Sticker ${userCollection.stickers.owned}/980,
        Fehlende: ${userCollection.stickers.missing.slice(0,10).join(', ')}...
        Adrenalyn: ${userCollection.cards.owned}/680`,
      messages: [{ role: "user", content: userMessage }]
    })
  });
  const data = await response.json();
  return data.content[0].text;
}
```

---

## Navigation

```
Bottom Navigation (5 Tabs):
[📷 Scan]  [📚 Album]  [🔄 Tausch]  [📅 Spiele]  [👤 Profil]
```

### Screen-Flow nach Scan

**Sticker gescannt:**
```
Scanner → Rückseite (Code ALG8) → Lookup → Bestätigung
┌────────────────────────────────┐
│ ✅ David Alaba · AUT4          │
│ Österreich · Gruppe J          │
│ Status: NEU / DOPPELT (2×)     │
│ [Album]         [Tauschen]     │
└────────────────────────────────┘
```

**Adrenalyn normal gescannt:**
```
Scanner → Nummer #191 → Lookup → Bestätigung
┌────────────────────────────────┐
│ Germany Team Crest · #191      │
│ Typ: TEAM_CREST · GER          │
│ Status: NEU hinzugefügt        │
│ [Album]         [Weiter]       │
└────────────────────────────────┘
```

**Golden Baller gescannt:**
```
Scanner → #4 + Gold-Design → Vorderseite OK
       → Rückseite → Activation Code: LCH-ZK-VIX
┌────────────────────────────────┐
│ ⭐ GOLDEN BALLER #4            │
│ Harry Kane · England           │
│ 100/100/100 = 300 Pkt.         │
│ Activation Code: LCH-ZK-VIX   │
│ [Code kopieren] [Weiter]       │
└────────────────────────────────┘
```

---

## Technische Architektur

```
StickerScout 2026
├── Frontend: React Native (Expo SDK 52+)
│   ├── expo-camera           — Kamera + ML Kit
│   ├── @react-navigation/native
│   ├── react-native-paper    — UI Components
│   ├── expo-location         — Geolokalisierung
│   ├── expo-localization     — AT-Preis-Erkennung
│   └── react-native-purchases — RevenueCat IAP
├── Backend: Firebase
│   ├── Firestore             — Sammlungen, Tausch, Freunde
│   ├── Firebase Auth         — Google/Apple Login
│   ├── Firebase Storage      — Exports
│   └── Firebase Functions    — Matching, Push, Completion
├── KI: Google ML Kit
│   ├── Text Recognition v2   — OCR für Codes + Nummern
│   └── Barcode Scanning      — QR-Promo-Codes
├── Externe APIs
│   ├── Claude API (Sonnet 4) — In-App Assistent
│   ├── AdMob                 — Werbung (Free-User)
│   └── Panini Affiliate      — Code 00540AD
└── Lokale Datenbanken
    ├── sticker_db_wc2026.json    v7.1 — 980+12+20 = 1.012
    └── adrenalyn_db_wc2026.json  v2.2 — 630+50 = 680
```

### Firebase Schema

```
users/{userId}
  ├── profile: { name, premium, scanCount, language, region, createdAt }
  ├── stickers/{id}:       { owned, count, forTrade, scannedAt }
  ├── cc_stickers/{id}:    { owned, count }
  ├── extra_stickers/{id}: { owned, count }
  ├── cards/{id}: {
  │     owned, count, forTrade,
  │     cardType,          // BASE | HERO | GOLDEN_BALLER | ...
  │     activationCode,    // nur Golden Baller
  │     codeRedeemed,
  │     scannedAt
  │   }
  └── dream_teams/{id}: { name, formation, players[], createdAt }

trades/{tradeId}
  ├── offeredBy, offeredItems, wantedItems
  ├── status: "open"|"matched"|"completed"|"cancelled"
  ├── location: GeoPoint
  └── createdAt

purchases/{userId}
  ├── wmPass: { purchased, purchasedAt, price }
  ├── scanBoosts: [{ amount, purchasedAt }]
  └── reportPDF: { purchased }
```

---

## Feature-Roadmap

```
11. JUNI 2026 — 🚀 LAUNCH v1.0
  ✅ Scanner (OCR, 3-Pfad-Flow: Sticker/Adrenalyn/Golden Baller)
  ✅ Album (1.012 Sticker + 680 Adrenalyn)
  ✅ Tauschbörse
  ✅ Completion Calculator
  ✅ In-App Assistent (Claude API)
  ✅ WM Pass + Micro-IAPs
  ✅ Spielplan & Bracket

ENDE JUNI 2026 — v1.1
  + Promo-Code-Scanner (QR/Coca-Cola)
  + Kettenmatching Tauschbörse
  + Freunde & Gruppen
  + Wert-Tracker (eBay-Marktpreise)

MITTE JULI 2026 — v1.2
  + Album-Seiten-Scanner (ganze Seite = 1 Scan)
  + KI Dream Team Coach

AUGUST 2026 — v2.0
  + Visuelle Sticker-Erkennung (TensorFlow Lite, trainiertes Modell)
  + Album Video-Scan
  + Multi-Kollektion Plattform
```

---

## App Store Metadaten

| Feld | Wert |
|---|---|
| App-Name | StickerScout 2026 |
| Bundle ID | `at.ncn.stickerscout2026` |
| Kategorie | Sports |
| Altersfreigabe | 4+ / PEGI 3 |
| Sprachen Launch | Deutsch, Englisch |

---

## Referenz-Dateien

| Datei | Version | Inhalt |
|---|---|---|
| `sticker_db_wc2026.json` | v7.1 | 1.012 Sticker, foto-verifiziert |
| `adrenalyn_db_wc2026.json` | v2.2 | 680 Karten inkl. Update Set |
| `StickerScout2026_Design_Update.md` | 1.0 | Farb-Tokens, Paywall-Specs, AT-Logik |
| `StickerScout2026_Monetarisierung.md` | 1.0 | Monetarisierungs-Details |
| `StickerScout2026_AppStore_Texte.md` | — | Store-Texte DE+EN |

---

# 🇬🇧 ENGLISH

## Project Context

Build **StickerScout 2026** — a React Native app for iOS and Android for the FIFA World Cup 2026. AI-powered companion for sticker and trading card collectors supporting BOTH official Panini collections.

**Base:** Same architecture as **AI Coin Collection Platform (CoinScanner)** — React Native, Firebase, Expo Camera + Google ML Kit.
**Developer:** NCN-NetConsulting GmbH (Austria)
**Launch:** June 11, 2026 | **Languages:** German + English + Spanish + Portuguese + French (5 languages, global market)

---

## Design System

See German section — same `colors.js` applies to all screens.
Primary background: `#0D1F2D` (Stadium Night), accent: `#F5C033` (WM Gold)

---

## Collections & Databases

### A) Panini Sticker Collection — `sticker_db_wc2026.json` v7.1

| Section | Count | ID Format |
|---|---|---|
| Base Stickers | 980 | `[TEAMCODE][1-20]` e.g. `AUT4` |
| Coca-Cola Stickers | 12 | `CC1`–`CC12` |
| Extra Stickers | 20 | `EXTRA1`–`EXTRA20` |
| **Total 100%** | **1,012** | |

**Sticker back side:** Every sticker has the player code on the back (e.g. `ALG8`). This is the primary input method in v1.0 (no visual AI recognition at launch).

### B) Panini Adrenalyn XL — `adrenalyn_db_wc2026.json` v2.2

| Set | Cards | Notes |
|---|---|---|
| Base Set | 630 | Cards #1–#630 |
| Update Set HERO | 48 | U01–U48, share number with BASE |
| Update Set Limited | 2 | Marc Cucurella (ESP), Giuliano Simeone (ARG) |
| **Total** | **680** | |

**Card number always visible top-left on the front of every card.**
HERO cards share the same number as the corresponding BASE card.
Golden Baller (#1–#9): gold foil, 100/100/100 = 300 pts, has activation code on back.

---

## Scan Flow v2 — Adaptive 3-Path Flow

> **⚠️ Visual AI recognition is NOT included in v1.0.**
> v1.0 uses OCR (Google ML Kit Text Recognition) and manual entry.
> Visual player recognition comes in v2.0 (August 2026).

```
SCAN FRONT
│
├── STICKER detected → SCAN BACK → read code e.g. "ALG8" → lookup
│                      Fallback: type code manually
│
├── ADRENALYN NORMAL → read number #XXX from top-left front → lookup
│                      Fallback: type number manually
│
└── GOLDEN BALLER (#1–#9, gold foil) → front + SCAN BACK
                                        → reads Activation Code (e.g. LCH-ZK-VIX)
                                        Fallback: type number manually
```

**Back scan tab** shown only for:
- ALL stickers (required for code)
- Golden Baller cards only (for activation code)
- NOT for normal Adrenalyn cards

---

## Monetization — WM Pass Model

**No subscription. One-time WM Pass + optional Micro-IAPs.**

| Product | Type | Price | Product ID |
|---|---|---|---|
| World Cup Pass 2026 | Non-consumable | €3.99 | `at.ncn.stickerscout2026.wmpass` |
| +50 Scan Boost | Consumable | €0.99 | `at.ncn.stickerscout2026.scan50` |
| +10 Trade Slots (7 days) | Consumable | €0.99 | `at.ncn.stickerscout2026.trade7d` |
| Collection Report PDF | Non-consumable | €0.99 | `at.ncn.stickerscout2026.report` |

| Region | Early Bird (until June 15) | Regular (from June 16) |
|---|---|---|
| Global | €2.99 | €3.99 |
| Austria (AT) | **€1.99** | €3.99 |

| Feature | Free | WM Pass |
|---|---|---|
| Scanner | **10/day** | Unlimited |
| Trade Exchange | 5 listings | Unlimited |
| Collection Report PDF | ❌ | ✅ (or €0.99) |
| Dream Team Builder | 1 team | Unlimited |
| Ads (AdMob) | ✅ | ❌ |

---

## Technical Architecture

Same as German section. Key additions:
- `expo-localization` for AT price detection
- `react-native-purchases` (RevenueCat) for IAP management
- `adrenalyn_db_wc2026.json` v2.2 — 680 cards

---

## Feature Roadmap

```
June 11, 2026  🚀 LAUNCH v1.0
  ✅ Scanner (OCR, 3-path flow)
  ✅ Album (1,012 stickers + 680 Adrenalyn)
  ✅ Trading Exchange
  ✅ Completion Calculator
  ✅ In-App Assistant (Claude API)
  ✅ WM Pass + Micro-IAPs

Late June  v1.1 — Promo codes, chain trading, friends
Mid July   v1.2 — Album page scanner, AI dream team coach
August     v2.0 — Visual sticker recognition (TFLite), video scan
```

---

*NCN-NetConsulting GmbH | StickerScout 2026 | Claude Code Prompt v3.1 | 3. Juni 2026*

---

# 🗓️ ENTWICKLUNGSPLAN & RELEASE-ZEITPLAN

## Sprint — 7 Tage bis Launch (4.–11. Juni 2026)

> **Heute: 3. Juni | Claude Code startet: 4. Juni | Launch: 11. Juni**
> App Store Review dauert 1–3 Tage → Submit spätestens 9. Juni.

### Tag 1 — 4. Juni: Projektsetup & Fundament

- [ ] Expo SDK 52+ Projekt initialisieren (Basis: CoinScanner-Architektur)
- [ ] Firebase konfigurieren (Auth, Firestore, Functions)
- [ ] Design System einrichten (`colors.js` — Stadion-Nacht #0D1F2D)
- [ ] Bottom Navigation (5 Tabs: Scan / Album / Tausch / Spiele / Profil)
- [ ] `sticker_db_wc2026.json` v7.1 + `adrenalyn_db_wc2026.json` v2.2 einbinden
- [ ] `StatusBar style="light"` global setzen
- [ ] i18n Setup (DE + EN + ES + PT + FR, alle Strings in `/locales/`)
- [ ] Locale-Dateien: `de.json`, `en.json`, `es.json`, `pt.json`, `fr.json`

### Tag 2 — 5. Juni: Scanner Screen

- [ ] Kamera-Viewfinder mit Google ML Kit
- [ ] **Schritt 1 — Typ-Auswahl:** [Sticker] [Adrenalyn-Karte] (KEIN Vorder/Rückseite-Toggle!)
- [ ] **Pfad A — Sticker:** NUR Rückseite scannen → OCR liest `ALG8` → Lookup sticker_db
- [ ] **Pfad B — Adrenalyn normal:** NUR Vorderseite scannen → OCR liest `191` → Lookup adrenalyn_db
- [ ] **Pfad C — Golden Baller:** Gold erkannt → Vorderseite + Rückseite → Activation Code
- [ ] Fallback: Manuelle Nummerneingabe (immer sichtbar)
- [ ] Scan-Bestätigung Screen (Spielerinfo, NEU / DOPPELT)
- [ ] Scan-Limit: 10/Tag (Free) / Unbegrenzt (WM Pass)

### Tag 3 — 6. Juni: Digitales Album

- [ ] **Tab A — Sticker (1.012)**
  - Grid nach Gruppen A–L
  - Sektionen: Coca-Cola CC1–CC12 / Extra EXTRA1–EXTRA20
  - Filter: vorhanden / fehlend / doppelt / FOIL
  - Fortschrittsbalken pro Team + Gesamt
- [ ] **Tab B — Adrenalyn XL (680)**
  - Grid nach Typ: Golden Baller / HERO / IC / FF / BASE / Special
  - HERO-Karten visuell unterscheidbar (goldener Rahmen)
  - Activation Code Status (nur Golden Baller)
- [ ] Karten-Detail Screen (Tap auf Karte)
- [ ] FlatList mit Virtualization (Performance für 1.012+ Items)

### Tag 4 — 7. Juni: Paywall & IAP

- [ ] RevenueCat SDK einrichten
- [ ] IAP Produkte konfigurieren:
  - `at.ncn.stickerscout2026.wmpass` (Non-consumable, €3,99)
  - `at.ncn.stickerscout2026.scan50` (Consumable, €0,99)
  - `at.ncn.stickerscout2026.trade7d` (Consumable, €0,99)
  - `at.ncn.stickerscout2026.report` (Non-consumable, €0,99)
- [ ] Early Bird Logik: €2,99 bis 15.06. / €1,99 AT bis 15.06.
- [ ] Österreich-Erkennung via `expo-localization`
- [ ] Paywall Screen (Design: Stadion-Nacht, Gold CTA)
- [ ] Countdown-Badge (Tage bis Early Bird Ende)
- [ ] AdMob für Free-User einrichten
- [ ] Restore Purchase Button

### Tag 5 — 8. Juni: Tauschbörse & Spielplan

- [ ] Tauschbörse: Angebote erstellen (Biete / Suche)
- [ ] Free Limit: 5 Angebote | WM Pass: Unbegrenzt
- [ ] Geo-Matching (Tauschpartner in der Nähe)
- [ ] Spielplan: alle 104 WM-Spiele (11. Juni – 19. Juli)
- [ ] Gruppe J (AUT) hervorgehoben
- [ ] WM Bracket Predictor

### Tag 6 — 9. Juni: Profil, Assistent, Klingeltöne & Polish

- [ ] Profil Screen (Fortschritt, Completion Calculator)
- [ ] In-App Assistent (Claude API, `claude-sonnet-4-20250514`)
- [ ] Completion Calculator mit PDF-Report (IAP oder WM Pass)
- [ ] Panini Affiliate Deep-Link (Code `00540AD`)
- [ ] **Klingeltöne Tab** (Töne bereits fertig, einbinden + IAP)
- [ ] Ringtone-Player (30-Sek. Preview + Vollversion-Kauf)
- [ ] "Als Klingelton setzen" Funktion (iOS M4R / Android MediaStore)
- [ ] Push Notifications Setup
- [ ] Bug-Fixes + Performance-Tests
- [ ] **iOS Build erstellen → App Store Connect Submit**
- [ ] **Android Build erstellen → Google Play Submit**

### Tag 7 — 10. Juni: Review & Hotfixes

- [ ] App Store Review läuft (1–3 Tage, sollte am 10. oder 11. fertig sein)
- [ ] Letzte Hotfixes wenn nötig
- [ ] Launch-Vorbereitung (Social Media, Pressemitteilung)

### 🚀 11. Juni — LAUNCH v1.0

---

## Release-Zeitplan

```
JUNI 2026
│
├─ 04. Juni   ████ Claude Code startet Entwicklung v1.0
├─ 09. Juni   📦 Submit App Store + Google Play
├─ 11. Juni   🚀 LAUNCH v1.0
│              ✅ Scanner (OCR, 3-Pfad-Flow)
│              ✅ Album (1.012 Sticker + 680 Adrenalyn)
│              ✅ Tauschbörse
│              ✅ Spielplan + Bracket
│              ✅ Completion Calculator
│              ✅ WM Pass + Micro-IAPs + Early Bird
│              ✅ In-App Assistent (Claude API)
│              ✅ DE + EN
│              ✅ 🔔 Klingeltöne Tab (Eigene Kompositionen, fertig)
│
├─ 15. Juni   💰 Early Bird endet → regulärer Preis €3,99
├─ 16. Juni   Gruppenphase läuft (WM gestartet)
│
├─ 25. Juni   🔄 UPDATE v1.1
│              + Promo-Code-Scanner (QR/Coca-Cola)
│              + Wert-Tracker (eBay-Marktpreise)
│              + Kettenmatching Tauschbörse (3-Wege)
│              + Freunde & Gruppen
│              + Weitere Klingeltöne (Erweiterung)
│
JULI 2026
│
├─ 04. Juli   K.o.-Runden beginnen
│
├─ 10. Juli   🔄 UPDATE v1.2
│              + Album-Seiten-Scanner
│              + KI Dream Team Coach
│              + Bracket Predictor mit AI-Odds
│
├─ 19. Juli   🏆 WM-FINALE (MetLife Stadium)
│
AUGUST 2026
│
└─ September  🚀 v2.0
               + Visuelle Sticker-Erkennung (TFLite)
               + Album Video-Scan
               + Multi-Kollektion Plattform
```

---

## Kritischer Pfad

```
Risiko:    App Store Review dauert 1-3 Tage
Puffer:    Submit 09. Juni → Review bis 11. Juni ✅
Backup:    Falls Review >3 Tage → Soft-Launch via TestFlight
           Google Play ist schneller (1-2 Tage)

Priorität wenn Zeit knapp:
  1. Scanner + Album (Kern-Feature)
  2. Paywall + IAP (Revenue)
  3. Tauschbörse (Nice-to-have für v1.0)
  4. Spielplan + Assistent (v1.0 oder v1.1)
```

*NCN-NetConsulting GmbH | StickerScout 2026 | Entwicklungsplan | 3. Juni 2026*

---

# 🎵 WM RINGTONES — Update v1.1 (Woche 2)

## Feature-Beschreibung

Neuer Tab **"Klingeltöne"** in der Bottom Navigation. User können WM-Klingeltöne anhören, als Klingelton setzen, und optional den vollständigen Song als Download kaufen.

> **✅ Töne bereits fertig produziert → Launch v1.0 (11. Juni)**

## Songs (final)

| ID | Künstler | Titel | Markt |
|---|---|---|---|
| song1 | United Voices | One World, One Game | 🌍 International (EN) |
| song2 | Leo Falk | Wir stehen zusammen | 🇩🇪 Deutschland (DE) |
| song3 | Da Austro-Bua | Unaufhoitboa | 🇦🇹 Österreich (AT) |

Cover-Artwork liegt vor (PNG) → in `assets/ringtones/covers/` ablegen:
- `song1_cover.png` — United Voices
- `song2_cover.png` — Leo Falk
- `song3_cover.png` — Da Austro-Bua

## Navigation

```
Bottom Navigation (6 Tabs):
[📷 Scan] [📚 Album] [🔄 Tausch] [📅 Spiele] [🔔 Töne] [👤 Profil]
```

**Tab-Icon:** `ti-bell-ringing` (Tabler Icons, Outline) — Gold (#F5C033) wenn aktiv

## Ringtones Screen

```
┌──────────────────────────────────┐
│  🔔 WM Klingeltöne               │
│                                  │
│  [OFFIZIELL]  [TEAMS]  [FANFARE] │  ← Filter
│                                  │
│  ┌────────────────────────────┐  │
│  │ ▶  WM 2026 Offizieller    │  │
│  │    Titelsong               │  │
│  │    Vorschau (30 Sek.)  🔔  │  │
│  │    [Vollständig €0,99]    │  │
│  └────────────────────────────┘  │
│                                  │
│  ┌────────────────────────────┐  │
│  │ ▶  WM Fanfare / Intro      │  │
│  │    Vorschau (30 Sek.)  🔔  │  │
│  │    [Vollständig €0,99]    │  │
│  └────────────────────────────┘  │
│                                  │
│  ┌────────────────────────────┐  │
│  │ ▶  Österreich Hymne (WM)   │  │
│  │    Vorschau (30 Sek.)  🔔  │  │
│  │    [Vollständig €0,99]    │  │
│  └────────────────────────────┘  │
│  ...                             │
└──────────────────────────────────┘
```

## IAP Produkt

| Produkt | Typ | Preis | Produkt-ID |
|---|---|---|---|
| One World, One Game – Ringtone | Non-consumable | €0,99 | `at.ncn.stickerscout2026.ringtone.song1` |
| Wir stehen zusammen – Klingelton | Non-consumable | €0,99 | `at.ncn.stickerscout2026.ringtone.song2` |
| Unaufhoitboa – Klingelton | Non-consumable | €0,99 | `at.ncn.stickerscout2026.ringtone.song3` |
| One World, One Game – Full Track | Non-consumable | €1,99 | `at.ncn.stickerscout2026.fulltrack.song1` |
| Wir stehen zusammen – Full Track | Non-consumable | €1,99 | `at.ncn.stickerscout2026.fulltrack.song2` |
| Unaufhoitboa – Full Track | Non-consumable | €1,99 | `at.ncn.stickerscout2026.fulltrack.song3` |

## Funktionen

- **Vorschau (kostenlos):** 30-Sekunden-Preview in der App
- **Klingelton (€0,99):** Kurzversion kaufen + als Klingelton setzen
- **Full Track (€1,99):** Vollständiger Song als Download — einmal kaufen, für immer besitzen
- **Upsell nach Klingelton-Kauf:** "Du hast den Klingelton — hol dir den ganzen Song für nur €1,00 mehr!"

## Ringtones Screen

```
┌─────────────────────────────────┐
│  [Cover Art]                    │
│  United Voices                  │
│  One World, One Game            │
│  ▶ Vorschau (30 Sek.)          │
│  [🔔 Klingelton  €0,99]        │
│  [⬇ Ganzer Song  €1,99]        │
│  ─────────────────────────────  │
│  [Cover Art]                    │
│  Leo Falk                       │
│  Wir stehen zusammen            │
│  ▶ Vorschau (30 Sek.)          │
│  [🔔 Klingelton  €0,99]        │
│  [⬇ Ganzer Song  €1,99]        │
│  ─────────────────────────────  │
│  [Cover Art]                    │
│  Da Austro-Bua 🇦🇹              │
│  Unaufhoitboa                   │
│  ▶ Vorschau (30 Sek.)          │
│  [🔔 Klingelton  €0,99]        │
│  [⬇ Ganzer Song  €1,99]        │
└─────────────────────────────────┘
```

## Upsell-Logik

```javascript
// Nach Klingelton-Kauf → Upsell Full Track anzeigen
function showFullTrackUpsell(songId) {
  const song = SONGS[songId];
  showModal({
    title: `Du hast den Klingelton! 🎵`,
    body: `Hol dir jetzt "${song.title}" als vollständigen Song
für nur €1,00 mehr!`,
    cta: `Ganzen Song laden — €1,99`,
    dismiss: `Nein danke`,
    productId: `at.ncn.stickerscout2026.fulltrack.${songId}`
  });
}
```

## Marketing-Texte (DE)

**Kaufbutton Klingelton:**
> 🔔 Klingelton setzen — €0,99

**Kaufbutton Full Track:**
> ⬇ Ganzen Song laden — €1,99

**Full Track Beschreibung:**
> Nicht nur Klingelton — das ganze Lied. Einmal kaufen, für immer besitzen. Offline hören, teilen, in voller Qualität.

**Song-spezifisch:**
- Song3 (AT): *Das Österreich-Lied zur WM 2026 — in voller Länge. Aus'm Herz, für immer deins.*
- Song2 (DE): *Das deutsche WM-Lied 2026 — vollständig, zum Mitnehmen. Dein Soundtrack für das Turnier.*
- Song1 (INT): *The official WM 2026 anthem — full version, yours forever.*

**Upsell-Text:**
> Du hast den Klingelton — hol dir jetzt den ganzen Song für nur €1,00 mehr!

## Technische Implementation

```javascript
import { Audio } from 'expo-av';
import * as FileSystem from 'expo-file-system';

// Vorschau abspielen
async function playPreview(ringtoneId) {
  const { sound } = await Audio.Sound.createAsync(
    { uri: `${CDN_URL}/ringtones/${ringtoneId}_preview.mp3` }
  );
  await sound.playAsync();
}

// Klingelton setzen (iOS: Shortcuts / Android: RingtoneManager)
async function setAsRingtone(ringtoneId, isPurchased) {
  const file = isPurchased ? 'full' : 'short';
  const localPath = `${FileSystem.documentDirectory}${ringtoneId}_${file}.mp3`;
  await FileSystem.downloadAsync(
    `${CDN_URL}/ringtones/${ringtoneId}_${file}.mp3`,
    localPath
  );
  // iOS: Teilen via Share Sheet als Klingelton-Datei (.m4r)
  // Android: MediaStore API für Klingelton-Registrierung
}
```

## ✅ Lizenz-Entscheidung: Eigene Kompositionen

Kein Lizenzrisiko, volle Rechte bei NCN. Geplant: 5–10 eigens produzierte WM-Klingeltöne.

**Empfohlene Tracks:**
- WM 2026 Hauptthema (episch, orchestral)
- Torjubel-Fanfare
- Österreich-inspirierter WM-Song (Heimmarkt)
- Spannungs-Countdown (K.o.-Phase)
- Siegeshymne / Champions-Motiv
- Stadion-Atmosphäre Loop

**Format:** ✅ MP3 (Android + Preview) + M4R (iOS Klingelton) — beide Formate vorhanden
**Anzahl:** 3 Songs × 2 Versionen (Ringtone + Full Track) = 6 Audio-Dateien
**Speicherort:** Lokal bei Roman → in `/assets/ringtones/` im App-Projekt ablegen

```
assets/
└── ringtones/
    ├── covers/
    │   ├── song1_cover.png     (United Voices — One World One Game)
    │   ├── song2_cover.png     (Leo Falk — Wir stehen zusammen)
    │   └── song3_cover.png     (Da Austro-Bua — Unaufhoitboa)
    ├── song1_preview.mp3       (30 Sek. Preview)
    ├── song1_ringtone.mp3      (Klingelton-Version)
    ├── song1_ringtone.m4r      (iOS Klingelton)
    ├── song1_full.mp3          (Vollständiger Track — IAP €1,99)
    ├── song2_preview.mp3
    ├── song2_ringtone.mp3
    ├── song2_ringtone.m4r
    ├── song2_full.mp3
    ├── song3_preview.mp3
    ├── song3_ringtone.mp3
    ├── song3_ringtone.m4r
    └── song3_full.mp3
```

**⚠️ Action für Roman:** Alle Dateien + Cover PNGs an Claude Code übergeben

## Tab-Icon Optionen

| Icon | Tabler Name | Eignung |
|---|---|---|
| 🔔 | `ti-bell-ringing` | ✅ Klar, universell |
| 🎵 | `ti-music` | ✅ Musik-Assoziation |
| 📳 | `ti-device-mobile-vibration` | okay |
| 🔊 | `ti-volume` | zu generisch |

**Empfehlung: `ti-bell-ringing`** — sofort erkennbar als Klingelton-Tab.

*NCN-NetConsulting GmbH | StickerScout 2026 | Ringtones Feature | 3. Juni 2026*

---

# 🔔 PUSH NOTIFICATIONS — Spezifikation

## Setup

```javascript
// expo-notifications + Firebase Cloud Messaging
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';

async function registerForPushNotifications() {
  if (!Device.isDevice) return null;
  const { status } = await Notifications.requestPermissionsAsync();
  if (status !== 'granted') return null;
  const token = (await Notifications.getExpoPushTokenAsync()).data;
  // Token in Firestore speichern:
  await firestore.doc(`users/${userId}`).update({ pushToken: token });
  return token;
}

// Notification Handler
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});
```

---

## Notification-Typen

### 1 — Scan-Limit erreicht
**Trigger:** User hat 10. Scan des Tages gemacht
**Timing:** Sofort
**Deeplink:** PaywallScreen

```json
{
  "title_de": "10 Scans aufgebraucht 📷",
  "title_en": "10 scans used up 📷",
  "title_es": "10 escaneos agotados 📷",
  "title_pt": "10 digitalizações esgotadas 📷",
  "title_fr": "10 scans épuisés 📷",
  "body_de": "Mit dem WM Pass scannst du unbegrenzt — für nur €3,99!",
  "body_en": "Scan unlimited with the World Cup Pass — only €3.99!",
  "body_es": "¡Escanea sin límites con el Pase Mundial — solo €3,99!",
  "body_pt": "Digitalize sem limites com o Passe Copa — apenas €3,99!",
  "body_fr": "Scannez sans limite avec le Pass CM — seulement €3,99 !"
}
```

### 2 — Österreich spielt (lokalisiert für AT-User)
**Trigger:** Firebase Scheduled Function, nur für AT-User (region === 'AT')
**Timing:** 2 Stunden vor Anpfiff

```json
{
  "17.06.2026 15:00": {
    "title_de": "🇦🇹 AUT vs JOR — heute! Anstoß um 17:00 Uhr",
    "body_de": "Scanne deine Österreich-Sticker und vervollständige das Album!"
  },
  "22.06.2026 21:00": {
    "title_de": "🇦🇹 AUT vs ARG — heute! Anstoß um 21:00 Uhr",
    "body_de": "Das Highlight der Gruppenphase — bist du bereit?"
  },
  "28.06.2026 21:00": {
    "title_de": "🇦🇹 AUT vs ALG — Gruppenfinale! Anstoß um 21:00 Uhr",
    "body_de": "Letztes Gruppenspiel — zeig dein AUT-Album!"
  }
}
```

### 3 — WM Match Reminder (alle User)
**Trigger:** Firebase Scheduled Function
**Timing:** 1 Stunde vor Anpfiff der Top-Spiele

```json
{
  "title_de": "⚽ {Team1} vs {Team2} — in 1 Stunde!",
  "body_de": "Hast du alle Sticker von {Team1} und {Team2}?",
  "title_en": "⚽ {Team1} vs {Team2} — in 1 hour!",
  "body_en": "Do you have all stickers for {Team1} and {Team2}?"
}
```

### 4 — Tausch-Match gefunden
**Trigger:** Firebase Function nach Matching-Algorithmus
**Timing:** Sofort nach Match

```json
{
  "title_de": "🔄 Tausch-Match! {Name} sucht was du hast",
  "body_de": "{Name} bietet {Sticker} und sucht {DeinSticker} — schreib ihm jetzt!",
  "title_en": "🔄 Trade match! {Name} wants what you have",
  "body_en": "{Name} offers {Sticker} and wants {YourSticker} — message now!"
}
```

### 5 — Early Bird läuft ab
**Trigger:** Firebase Scheduled Function
**Timing:** 24h vor Early Bird Ende (14. Juni 23:59)

```json
{
  "title_de": "⏰ Letzter Tag: WM Pass für €2,99",
  "body_de": "Morgen steigt der Preis auf €3,99 — jetzt noch zuschlagen!",
  "title_en": "⏰ Last day: World Cup Pass for €2.99",
  "body_en": "Price goes up to €3.99 tomorrow — get it now!"
}
```

### 6 — Album-Meilenstein
**Trigger:** Client-seitig nach jedem Scan
**Timing:** Sofort bei 25% / 50% / 75% / 90%

```json
{
  "25%": {
    "title_de": "🎯 25% deines Albums komplett!",
    "body_de": "Noch 757 Sticker bis zur Vollsammlung — du schaffst das!"
  },
  "50%": {
    "title_de": "🔥 Halbzeit! 50% komplett",
    "body_de": "506 Sticker fehlen noch — wann tauschst du das nächste Mal?"
  },
  "75%": {
    "title_de": "⭐ 75% — fast da!",
    "body_de": "Nur noch 253 Sticker. Jetzt Completion Report ansehen?"
  },
  "90%": {
    "title_de": "🏆 90%! Die Ziellinie ist in Sicht",
    "body_de": "Nur noch 101 Sticker. Bestell die Fehlenden direkt bei Panini!"
  }
}
```

### 7 — Golden Baller gescannt
**Trigger:** Client-seitig nach Golden Baller Scan
**Timing:** Sofort

```json
{
  "title_de": "⭐ Golden Baller gescannt!",
  "body_de": "Du hast {SpielerName} — eine der 9 wertvollsten Karten!",
  "title_en": "⭐ Golden Baller scanned!",
  "body_en": "You got {PlayerName} — one of the 9 most valuable cards!"
}
```

### 8 — Tausch abgeschlossen
**Trigger:** Firebase Function nach Trade-Completion
**Timing:** Sofort

```json
{
  "title_de": "✅ Tausch erfolgreich!",
  "body_de": "Du hast {Sticker} erhalten. Öffne die App um dein Album zu updaten.",
  "title_en": "✅ Trade completed!",
  "body_en": "You received {Sticker}. Open the app to update your album."
}
```

---

## Firebase Cloud Functions — Scheduling

```javascript
// functions/index.js

const { onSchedule } = require('firebase-functions/v2/scheduler');
const admin = require('firebase-admin');

// Österreich Spiele
exports.notifyAUTvsJOR = onSchedule('0 15 17 6 *', async () => {
  await sendToATUsers({
    title: '🇦🇹 AUT vs JOR — heute! Anstoß um 17:00 Uhr',
    body: 'Scanne deine Österreich-Sticker und vervollständige das Album!'
  });
});

exports.notifyAUTvsARG = onSchedule('0 19 22 6 *', async () => {
  await sendToATUsers({
    title: '🇦🇹 AUT vs ARG — heute! Anstoß um 21:00 Uhr',
    body: 'Das Highlight der Gruppenphase — bist du bereit?'
  });
});

exports.notifyAUTvsALG = onSchedule('0 19 28 6 *', async () => {
  await sendToATUsers({
    title: '🇦🇹 AUT vs ALG — Gruppenfinale!',
    body: 'Letztes Gruppenspiel — zeig dein AUT-Album!'
  });
});

// Early Bird Ablauf
exports.notifyEarlyBirdEnd = onSchedule('0 10 14 6 *', async () => {
  await sendToAllUsers({
    title_de: '⏰ Letzter Tag: WM Pass für €2,99',
    title_en: '⏰ Last day: World Cup Pass for €2.99',
    title_es: '⏰ Último día: Pase Mundial por €2,99',
    title_pt: '⏰ Último dia: Passe Copa por €2,99',
    title_fr: '⏰ Dernier jour: Pass CM pour €2,99',
    body_de: 'Morgen steigt der Preis auf €3,99!',
    // ... andere Sprachen
  });
});

async function sendToATUsers(notification) {
  const snapshot = await admin.firestore()
    .collection('users')
    .where('region', '==', 'AT')
    .where('pushToken', '!=', null)
    .get();
  const tokens = snapshot.docs.map(d => d.data().pushToken);
  return sendPushBatch(tokens, notification);
}

async function sendToAllUsers(notification) {
  const snapshot = await admin.firestore()
    .collection('users')
    .where('pushToken', '!=', null)
    .get();
  // Lokalisiert nach user.language senden
  for (const doc of snapshot.docs) {
    const { pushToken, language = 'de' } = doc.data();
    await sendPush(pushToken, {
      title: notification[`title_${language}`] || notification.title_de,
      body:  notification[`body_${language}`]  || notification.body_de,
    });
  }
}

async function sendPushBatch(tokens, notification) {
  const message = {
    notification: { title: notification.title, body: notification.body },
    tokens,
  };
  return admin.messaging().sendEachForMulticast(message);
}
```

---

## Firestore User-Schema (Ergänzung Push)

```javascript
// users/{userId}
{
  pushToken: string,        // Expo Push Token
  pushEnabled: boolean,     // User-Präferenz
  language: 'de'|'en'|'es'|'pt'|'fr',
  region: string,           // 'AT', 'DE', 'BR', etc.
  notificationPrefs: {
    scanLimit: true,        // Scan-Limit erreicht
    matchReminder: true,    // Spielerinnerungen
    tradeMatch: true,       // Tausch-Matches
    milestones: true,       // Album-Meilensteine
    earlyBird: true,        // Angebote
  }
}
```

---

## Notification Settings Screen

User kann in den Einstellungen wählen welche Notifications er erhält:

```
Benachrichtigungen
├── ✅ Scan-Limit erreicht
├── ✅ Spielerinnerungen (WM-Matches)
├── ✅ Tausch-Matches gefunden
├── ✅ Album-Meilensteine
└── ✅ Angebote & Early Bird
```

*NCN-NetConsulting GmbH | StickerScout 2026 | Push Notifications | 3. Juni 2026*
