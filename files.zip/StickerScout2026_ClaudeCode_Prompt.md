# StickerScout 2026 — Claude Code Prompt
**NCN-NetConsulting GmbH | Version 2.0 | Juni 2026**

---

---

# 🇩🇪 DEUTSCH

## Projektkontext

Entwickle **StickerScout 2026** — eine React Native App für iOS und Android zur FIFA Fußball-Weltmeisterschaft 2026. Die App ist der KI-gestützte Begleiter für Sticker- und Trading-Card-Sammler und unterstützt BEIDE offiziellen Panini-Kollektionen zur WM 2026 — plus alle Sondereditions-Sticker.

**Basis:** Gleiche Architektur wie unsere bestehende App **AI Coin Collection Platform (CoinScanner)** — React Native, Firebase, Expo Camera + Google ML Kit.

**Developer:** NCN-NetConsulting GmbH (Österreich)
**Target date:** Launch zum WM-Start, 11. Juni 2026

---

## Kollektionen & Datenbanken

### A) Panini Sticker-Kollektion
Datei: `sticker_db_wc2026.json`

| Sektion | Anzahl | Beschreibung |
|---|---|---|
| Base Sticker | 980 | 48 Teams + Intro/Museum |
| Coca-Cola Sticker | 12 (CC1–CC12) | Unter Flaschendeckeln versteckt |
| Extra Sticker | 20 (EXTRA1–EXTRA20) | 1:100 Tüten, extrem selten |
| **Total für 100%** | **1.012** | Vollständiges Album |

**Alphanumerisches Nummerierungssystem:**
- Teams: `[TEAMCODE][1-20]` — z.B. `AUT4` = David Alaba
- Intro/Museum: `00`, `FWC1`–`FWC19`
- Coca-Cola: `CC1`–`CC12`
- Extra: `EXTRA1`–`EXTRA20`

**48 Teams in 12 Gruppen:**
```
A: MEX RSA KOR CZE   |  G: BEL EGY IRN NZL
B: CAN BIH QAT SUI   |  H: ESP CPV KSA URU
C: BRA MAR HAI SCO   |  I: FRA SEN IRQ NOR
D: USA PAR AUS TUR   |  J: ARG ALG AUT JOR
E: GER CUW CIV ECU   |  K: POR COD UZB COL
F: NED JPN SWE TUN   |  L: ENG CRO GHA PAN
```

**Coca-Cola Sticker (CC1–CC12):**
```
CC1  Lamine Yamal      (Spain)       FOIL
CC2  Joshua Kimmich    (Germany)     FOIL
CC3  Eduardo Camavinga (France)      FOIL
CC4  Josko Gvardiol    (Croatia)     FOIL
CC5  Federico Valverde (Uruguay)     FOIL
CC6  Virgil van Dijk   (Netherlands) FOIL
CC7  Alphonso Davies   (Canada)      FOIL
CC8  Raúl Jiménez      (Mexico)      FOIL
CC9  William Saliba    (France)      FOIL
CC10 Lautaro Martínez  (Argentina)   FOIL
CC11 Harry Kane        (England)     FOIL
CC12 Antonee Robinson  (USA)         FOIL
```
**Hinweis:** Regionale Varianten existieren (EUR / NAUO / LATAM / RoW). App erkennt alle Versionen.

### B) Panini Adrenalyn XL Trading Cards (630 Karten)
- 417 Base Cards + 213 Special Cards
- Kategorien: Heroes, Fan Favourites, Icons, Team Logos, Top Keepers, Defensive Rocks, Midfield Maestros, Goal Machines, Master Rookies (16), Golden Baller (9), Eternos 22 (22)
- Limited Editions: in separaten Produkten (Tins, Premium Packs)
- Momentum Cards: Bellingham, Dembélé, Pulisic (Dream Box exklusiv)
- **Jede Karte enthält einen Online-Game-Code** (Rückseite) für das offizielle Adrenalyn XL Spiel

---

## Features — Vollständig

### 1. KI-SCANNER

**Drei Scan-Modi:**

| Modus | Erkennt | Lookup |
|---|---|---|
| Sticker-Scan | Teamcode + Nummer (z.B. `AUT4`) | sticker_db_wc2026.json |
| Coca-Cola-Scan | CC-Code auf Etikett | CC1–CC12 |
| Adrenalyn XL Scan | Kartennummer + Kategorie | adrenalyn_db_wc2026.json |

**Album-Seiten-Scanner (NEU):**
- Kamera auf eine ganze Album-Seite richten
- ML Kit erkennt alle Sticker auf der Seite gleichzeitig
- Automatisches Eintragen aller erkannten Sticker ins digitale Album
- Spart stundenlange manuelle Eingabe

**Promo-Code-Scanner (NEU):**
- Scannt QR-Codes / Textcodes von:
  - Adrenalyn XL Packs (Online-Game-Codes)
  - Coca-Cola Flaschen (tägliche digitale Packs)
  - Panini/FIFA/McDonald's Promo-Codes
- Verwaltung gescannter Codes (eingelöst / verfügbar)

**Scan-Limits:**
- Free: 20 Scans/Tag
- Premium: Unbegrenzt

### 2. DIGITALES ALBUM

**Tab A — Sticker (980 + 12 CC + 20 Extra = 1.012)**
- Grid-Ansicht nach Gruppen A–L geordnet
- Eigene Sektion: "Coca-Cola Special" (CC1–CC12)
- Eigene Sektion: "Extra Sticker" (EXTRA1–EXTRA20, mit Seltenheitsanzeige)
- Filter: vorhanden / doppelt / fehlend / FOIL / CC / Extra
- Fortschrittsbalken: Album (980), CC-Seite (12), Extras (20), Gesamt (1.012)

**Tab B — Adrenalyn XL (630)**
- Grid-Ansicht nach Kategorie
- Seltenheitsstufen: Standard / Rare / Ultra Rare / Limited / Momentum
- Golden Baller & Eternos 22 gesondert hervorgehoben
- Online-Code-Status: eingelöst / verfügbar

### 3. COMPLETION CALCULATOR (NEU)

Statistische Berechnung nach dem "Coupon Collector's Problem":

```
Eingabe:  Aktuelle Sammlung (z.B. 450/980 Sticker)
Ausgabe:
  - Erwartete Anzahl noch benötigter Tüten: ~187
  - Kosten bei €0,60/Tüte: ~€112
  - Wahrscheinlichkeit, in X Tüten fertig zu sein: Kurve
  - Effizienzbonus durch aktiven Tausch: ~30% weniger Tüten
```

Premium-Feature: Personalised Completion Report (PDF-Export)

### 4. TAUSCHBÖRSE

- User kann Doppelte einstellen (Sticker UND Karten UND CC-Sticker)
- Matching-Algorithmus: gegenseitiger Bedarf → Match
- Geolokalisierung: Tauschpartner in der Nähe bevorzugen
- In-App-Chat
- Free: 5 aktive Angebote | Premium: Unbegrenzt + Priority-Matching
- **Panini Nachbestellservice Deep-Link (NEU):** Button in "Fehlende Sticker"-Liste → direkter Link zu panini.de/nachbestellservice mit vorausgefüllter Fehlerliste

### 5. FREUNDE & GRUPPEN (NEU)

- Freunde per Link / QR-Code einladen
- Sammlungsvergleich: Wer hat was, das der andere braucht?
- Gruppen-Challenge: Wer füllt das Album zuerst?
- Geteilter Fortschrittsbalken in Freundesgruppe
- Tausch direkt aus Freundesliste initiieren

### 6. SPIELPLAN & ERGEBNISSE

- Alle 104 WM-Spiele (11. Juni – 19. Juli 2026)
- Live-Score-Integration
- **WM-TIPP / BRACKET PREDICTOR (NEU):**
  - Alle 12 Gruppen vorhersagen
  - K.o.-Runden-Bracket ausfüllen
  - Mit Freunden teilen / vergleichen
  - Österreich-Spiele (Gruppe J) hervorgehoben

### 7. ADRENALYN XL DREAM TEAM BUILDER (NEU)

- Aus gescannten Karten ein 11er-Team zusammenstellen
- Formation wählen (4-3-3, 4-4-2, 3-5-2 etc.)
- Team-Stärke berechnen (basierend auf Kartenkategorie/Seltenheit)
- Dream Team als Bild exportieren und teilen
- Premium: Unbegrenzte Teams speichern

### 8. STATISTIKEN & DASHBOARD

- Sammel-Fortschritt: Sticker + CC + Extra + Adrenalyn XL
- Tauschhistorie
- **Marktwert-Tracker (NEU):** Geschätzte Sekundärmarkt-Preise für seltene Sticker (Golden Baller, Limited Editions, Extra-Sticker) — basierend auf eBay-Daten
- Premium: Erweiterte Charts, Completion Calculator Report, Export

---

## Technische Architektur

```
StickerScout 2026
├── Frontend: React Native (Expo SDK 52+)
│   ├── expo-camera           — Kamera + ML Kit
│   ├── @react-navigation/native — Navigation
│   ├── react-native-paper    — UI Components
│   ├── expo-location         — Geolokalisierung
│   └── react-native-share    — Team/Bracket teilen
├── Backend: Firebase
│   ├── Firestore             — Sammlungen, Tauschbörse, Freunde
│   ├── Firebase Auth         — Google/Apple Login
│   ├── Firebase Storage      — Profilbilder, Team-Exports
│   └── Firebase Functions    — Matching, Push-Notifications, Completion-Calc
├── KI: Google ML Kit
│   ├── Text Recognition v2   — Stickernummer + Code OCR
│   ├── Image Labeling        — Foil-Erkennung
│   ├── Document Scanner      — Album-Seiten-Scan (NEU)
│   └── Barcode Scanning      — QR-Code / Promo-Codes (NEU)
└── Lokale Datenbanken (gebündelt mit App)
    ├── sticker_db_wc2026.json    — 980 + 12 CC + 20 Extra
    └── adrenalyn_db_wc2026.json  — 630 Karten
```

### Sticker Lookup (inkl. aller Sektionen)

```javascript
import db from './assets/sticker_db_wc2026.json';

function lookupSticker(id) {
  // Coca-Cola Sticker
  if (id.startsWith('CC')) {
    return db.coca_cola_stickers.find(s => s.id === id) || null;
  }
  // Extra Sticker
  if (id.startsWith('EXTRA')) {
    return db.extra_stickers.find(s => s.id === id) || null;
  }
  // Intro / Museum
  if (id.startsWith('FWC') || id === '00') {
    return db.intro_stickers.find(s => s.id === id) || null;
  }
  // Team Sticker: z.B. AUT4
  const teamCode = id.replace(/\d+$/, '');
  const team = db.teams.find(t => t.code === teamCode);
  if (!team) return null;
  const sticker = team.stickers.find(s => s.id === id);
  return sticker ? { ...sticker, team: team.name, group: team.group } : null;
}

// Completion Calculator
function calcCompletion(owned, total = 980) {
  const missing = total - owned;
  // Expected packs needed = H(total) * total / (total - owned)
  // Simplified: expected additional stickers needed with duplicates
  const expectedPacks = Math.round(missing * (total / (missing + 1)) / 7);
  return {
    owned, missing, total,
    expectedPacksNeeded: expectedPacks,
    estimatedCostEUR: (expectedPacks * 0.60).toFixed(2),
    completionPct: ((owned / total) * 100).toFixed(1)
  };
}
```

### Firebase Firestore Schema

```
users/{userId}
  ├── profile:     { name, premium, scanCount, language, createdAt }
  ├── stickers/{id}:  { owned, count, forTrade, scannedAt }
  ├── cc_stickers/{id}: { owned, count, forTrade }
  ├── extra_stickers/{id}: { owned, count }
  ├── cards/{id}:  { owned, count, forTrade, codeRedeemed, scannedAt }
  ├── friends/[userId]: { addedAt }
  └── dream_teams/{teamId}: { name, formation, players[], createdAt }

trades/{tradeId}
  ├── offeredBy:    userId
  ├── offeredItems: [{ type: "sticker"|"card"|"cc", id, name }]
  ├── wantedItems:  [{ type: "sticker"|"card"|"cc", id, name }]
  ├── status:       "open"|"matched"|"completed"|"cancelled"
  ├── location:     GeoPoint
  └── createdAt:    timestamp

bracket_predictions/{userId}
  ├── groups:  { A: { winner, runner_up }, ... }
  ├── r16:     [{ match, prediction }]
  ├── qf, sf, final: [...]
  └── updatedAt: timestamp
```

---

## Monetarisierung

| Feature | Free | Premium (€1,99/Mo.) |
|---|---|---|
| KI-Scanner | 20/Tag | Unbegrenzt |
| Album-Seiten-Scanner | 3/Tag | Unbegrenzt |
| Sticker + CC + Extra Album | ✅ | ✅ |
| Adrenalyn XL Album | ✅ | ✅ |
| Completion Calculator | Basic | Vollständig + PDF |
| Tauschbörse | 5 Angebote | Unbegrenzt |
| Priority-Matching | ❌ | ✅ |
| Dream Team Builder | 1 Team | Unbegrenzt |
| WM-Tipp/Bracket | ✅ | ✅ |
| Marktwert-Tracker | Top 10 | Alle seltenen |
| Freunde/Gruppen | 5 Freunde | Unbegrenzt |
| Werbung (AdMob) | ✅ | ❌ |

---

## App Store Metadaten

- **App-Name:** StickerScout 2026
- **Bundle ID iOS:** at.ncn.stickerscout2026
- **Package Name Android:** at.ncn.stickerscout2026
- **Kategorie:** Sports / Unterhaltung
- **Altersfreigabe:** 4+ / PEGI 3

---

---

# 🇬🇧 ENGLISH

## Project Context

Build **StickerScout 2026** — a React Native app for iOS and Android for the FIFA World Cup 2026. AI-powered companion for sticker and trading card collectors, supporting BOTH official Panini collections plus all special edition stickers.

**Base:** Same architecture as **AI Coin Collection Platform (CoinScanner)** — React Native, Firebase, Expo Camera + Google ML Kit.

**Developer:** NCN-NetConsulting GmbH (Austria)  
**Target date:** Launch for World Cup kick-off, June 11, 2026

---

## Collections & Databases

### A) Panini Sticker Collection
File: `sticker_db_wc2026.json`

| Section | Count | Description |
|---|---|---|
| Base Stickers | 980 | 48 teams + intro/museum |
| Coca-Cola Stickers | 12 (CC1–CC12) | Hidden under bottle labels |
| Extra Stickers | 20 (EXTRA1–EXTRA20) | 1:100 packs, extremely rare |
| **Total for 100%** | **1,012** | Complete album |

**Sticker ID format:** `[TEAMCODE][1-20]` (e.g. `AUT4` = David Alaba)  
Special: `CC1–CC12` (Coca-Cola), `EXTRA1–EXTRA20`, `FWC1–FWC19`, `00`

**Coca-Cola Stickers (CC1–CC12) — EUR version:**
```
CC1  Lamine Yamal / ESP   CC7  Alphonso Davies / CAN
CC2  Joshua Kimmich / GER CC8  Raúl Jiménez / MEX
CC3  E. Camavinga / FRA   CC9  William Saliba / FRA
CC4  Josko Gvardiol / CRO CC10 Lautaro Martínez / ARG
CC5  Federico Valverde/URU CC11 Harry Kane / ENG
CC6  Virgil van Dijk / NED CC12 Antonee Robinson / USA
```
Note: Regional variants exist (EUR/NAUO/LATAM/RoW). App recognizes all versions.

### B) Panini Adrenalyn XL Trading Cards (630)
- 417 Base Cards + 213 Special Cards
- Each card has an Online Game Code on the reverse for the official Adrenalyn XL game
- Limited Editions: in Tins, Premium Packs, Special Boxes
- Momentum Cards: Bellingham, Dembélé, Pulisic (Dream Box exclusive)

---

## Features — Complete

### 1. AI SCANNER

**Three Scan Modes:**
- **Sticker Mode**: OCR reads team code + number → lookup in sticker_db
- **Coca-Cola Mode**: Scans CC code on bottle label → CC1–CC12
- **Adrenalyn XL Mode**: Reads card number + category → adrenalyn_db

**Album Page Scanner (NEW):**
- Point camera at full album page
- ML Kit Document Scanner identifies all stickers simultaneously
- Auto-adds all detected stickers to digital collection
- Eliminates hours of manual entry

**Promo Code Scanner (NEW):**
- Scans QR codes / text codes from:
  - Adrenalyn XL packs (online game codes)
  - Coca-Cola bottles (daily digital packs)
  - Panini / FIFA / McDonald's promo codes
- Tracks code status: redeemed / available

### 2. DIGITAL ALBUM

**Tab A — Stickers (980 + 12 CC + 20 Extra = 1,012)**
- Grid view by Groups A–L
- Dedicated section: "Coca-Cola Special" (CC1–CC12)
- Dedicated section: "Extra Stickers" (EXTRA1–EXTRA20, rarity indicator)
- Filters: owned / duplicate / missing / FOIL / CC / Extra
- Progress bars: Album (980), CC page (12), Extras (20), Total (1,012)

**Tab B — Adrenalyn XL (630)**
- Grid by category with rarity tiers
- Golden Baller & Eternos 22 highlighted
- Online code status per card

### 3. COMPLETION CALCULATOR (NEW)

Statistical calculation based on the Coupon Collector's Problem:

```
Input:  Current collection (e.g. 450/980 stickers)
Output:
  — Expected additional packs needed: ~187
  — Estimated cost at €0.60/pack: ~€112
  — Probability curve for completing in X packs
  — Efficiency bonus with active trading: ~30% fewer packs
```

Premium: Full personalized completion report (PDF export)

### 4. TRADING EXCHANGE

- List duplicates (stickers, Adrenalyn XL cards, CC stickers)
- Smart matching algorithm
- Geolocation: prefer nearby partners
- In-app chat
- Free: 5 listings | Premium: Unlimited + Priority matching
- **Panini Order Service Deep-Link (NEW):** "Missing stickers" list → direct link to Panini's official replacement service with pre-filled missing list

### 5. FRIENDS & GROUPS (NEW)

- Invite friends via link / QR code
- Collection comparison: who has what you need?
- Group challenge: who completes first?
- Shared progress bar
- Initiate trades directly from friends list

### 6. MATCH SCHEDULE & RESULTS

- All 104 WC 2026 matches (June 11 – July 19)
- Live score integration
- **WM BRACKET PREDICTOR (NEW):**
  - Predict all 12 group standings
  - Fill knockout bracket
  - Share / compare with friends
  - Austria matches (Group J) highlighted

### 7. ADRENALYN XL DREAM TEAM BUILDER (NEW)

- Build an 11-player team from scanned cards
- Choose formation (4-3-3, 4-4-2, 3-5-2 etc.)
- Team strength score based on card category/rarity
- Export and share team image
- Premium: Unlimited saved teams

### 8. STATISTICS & DASHBOARD

- Progress: Stickers + CC + Extra + Adrenalyn XL
- Trade history
- **Market Value Tracker (NEW):** Estimated secondary market prices for rare stickers (Golden Baller, Limited Editions, Extra stickers) — based on eBay/market data
- Premium: Full analytics, completion calculator report, export

---

## Technical Architecture

```
StickerScout 2026
├── Frontend: React Native (Expo SDK 52+)
│   ├── expo-camera           — Camera + ML Kit
│   ├── @react-navigation/native
│   ├── react-native-paper    — UI
│   ├── expo-location         — Geolocation
│   └── react-native-share    — Dream Team / Bracket sharing
├── Backend: Firebase
│   ├── Firestore             — Collections, trades, friends, brackets
│   ├── Firebase Auth         — Google / Apple Sign-In
│   ├── Firebase Storage      — Profile images, team exports
│   └── Firebase Functions    — Matching, push notifications, completion calc
├── AI: Google ML Kit
│   ├── Text Recognition v2   — Sticker number + code OCR
│   ├── Image Labeling        — Foil detection
│   ├── Document Scanner      — Album page scan (NEW)
│   └── Barcode Scanning      — QR / promo codes (NEW)
└── Local Databases (bundled)
    ├── sticker_db_wc2026.json    — 980 + 12 CC + 20 Extra
    └── adrenalyn_db_wc2026.json  — 630 cards
```

### Key Code Snippets

```javascript
// Complete sticker lookup (all sections)
import db from './assets/sticker_db_wc2026.json';

function lookupSticker(id) {
  if (id.startsWith('CC'))    return db.coca_cola_stickers.find(s => s.id === id);
  if (id.startsWith('EXTRA')) return db.extra_stickers.find(s => s.id === id);
  if (id.startsWith('FWC') || id === '00')
                              return db.intro_stickers.find(s => s.id === id);
  const teamCode = id.replace(/\d+$/, '');
  const team = db.teams.find(t => t.code === teamCode);
  const sticker = team?.stickers.find(s => s.id === id);
  return sticker ? { ...sticker, team: team.name, group: team.group } : null;
}

// Completion Calculator
function calcCompletion(owned, total = 980) {
  const missing = total - owned;
  const expectedPacks = Math.round(missing * (total / (missing + 1)) / 7);
  return {
    owned, missing, total,
    expectedPacksNeeded: expectedPacks,
    estimatedCostEUR: (expectedPacks * 0.60).toFixed(2),
    completionPct: ((owned / total) * 100).toFixed(1)
  };
}
```

### Firebase Schema

```
users/{userId}
  ├── profile: { name, premium, scanCount, language, createdAt }
  ├── stickers/{id}:     { owned, count, forTrade, scannedAt }
  ├── cc_stickers/{id}:  { owned, count, forTrade }
  ├── extra_stickers/{id}: { owned, count }
  ├── cards/{id}: { owned, count, forTrade, codeRedeemed, scannedAt }
  ├── friends/[userId]: { addedAt }
  └── dream_teams/{id}: { name, formation, players[], createdAt }

trades/{tradeId}
  ├── offeredBy, offeredItems, wantedItems
  ├── status: "open"|"matched"|"completed"|"cancelled"
  ├── location: GeoPoint
  └── createdAt: timestamp

bracket_predictions/{userId}
  ├── groups: { A: { winner, runnerUp }, ... }
  ├── r16, qf, sf, final: [predictions]
  └── updatedAt: timestamp
```

---

## Monetization

| Feature | Free | Premium (€1.99/mo.) |
|---|---|---|
| AI Scanner | 20/day | Unlimited |
| Album Page Scanner | 3/day | Unlimited |
| Sticker + CC + Extra Album | ✅ | ✅ |
| Adrenalyn XL Album | ✅ | ✅ |
| Completion Calculator | Basic | Full + PDF |
| Trading Exchange | 5 listings | Unlimited |
| Priority Matching | ❌ | ✅ |
| Dream Team Builder | 1 team | Unlimited |
| WM Bracket Predictor | ✅ | ✅ |
| Market Value Tracker | Top 10 | All rare items |
| Friends / Groups | 5 friends | Unlimited |
| Ads (AdMob) | ✅ | ❌ |

---

## Reference Files

| File | Content |
|---|---|
| `sticker_db_wc2026.json` | Complete sticker DB v3.0: 980 + CC1-CC12 + Extra1-20 |
| `StickerScout2026_AppStore_Texte.md` | Store texts DE+EN, Apple + Google Play |

*NCN-NetConsulting GmbH | StickerScout 2026 | Version 2.0 | Juni 2026*
